package com.fitndonatepg.fit;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class two extends AppCompatActivity {
TextView  t;
    Button bb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_two);
        t=(TextView)findViewById(R.id.textView5);
        String s=getIntent().getStringExtra("donate");
        Float f=Float.parseFloat(s);
        t.setText("You earned "+Float.toString(f)+"miles");
        bb=(Button) findViewById(R.id.bb);
        bb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i2=new Intent((two.this),  third.class);
                startActivity(i2);
            }
        });
    }
}
