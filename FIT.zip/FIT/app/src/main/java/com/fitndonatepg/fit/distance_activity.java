package com.fitndonatepg.fit;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.SystemClock;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.Chronometer;
import android.widget.TextView;
import android.widget.Toast;

public class distance_activity extends AppCompatActivity {

    Chronometer mchrono;

    int c;
    double l1, l2, startl, startll;
    private Button button,stop;
    private TextView textView;
    private LocationManager locationManager;
    private LocationListener locationListener;
    private Location loc,lp;
    private TextView t2;
    double m;
    float t,speed;
    private int i;
    private TextView t3;
    private TextView t4;
    private  long m4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_distance_activity);
        button = (Button) findViewById(R.id.b);
        stop=(Button)findViewById(R.id.stop);
        textView = (TextView) findViewById(R.id.textView);
        t2=(TextView)findViewById(R.id.t3);
        t3=(TextView)findViewById(R.id.t2);

        t4=(TextView)findViewById(R.id.t4);
        mchrono= (Chronometer)findViewById(R.id.mchrono);
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        c=0;
        i=0;
        speed=0.0f;
        m=0.0f;
        t=0.0f;




        locationListener = new LocationListener() {
            @Override
            public void onLocationChanged(Location location) {
                if(c==0) {
                    loc = new Location("point B");
                    loc.setLatitude(location.getLatitude());
                    loc.setLongitude(location.getLongitude());
                    mchrono.setBase(SystemClock.elapsedRealtime());
                    mchrono.start();
                    c++;
                }
                i++;
                lp=new Location("point A");
                lp.setLatitude(location.getLatitude());
                lp.setLongitude(location.getLongitude());

                textView.setText("Coordinates are: "+Integer.toString(i++)+location.getLatitude()+ "  ,"+ location.getLongitude());
            }

            @Override
            public void onStatusChanged(String s, int i, Bundle bundle) {

            }

            @Override
            public void onProviderEnabled(String s) {

            }

            @Override
            public void onProviderDisabled(String s) {
                Intent i = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                startActivity(i);
            }
        };


        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        configurebutton();

        stop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                m=loc.distanceTo(lp);

                t3.setText(Double.toString(m));
                long m4 = SystemClock.elapsedRealtime() - mchrono.getBase();

                t=(float)(m4*0.000000277778);
                t2.setText(Float.toString(t));
                speed= (float)(m/1000)/t;
                t4.setText("Speed is "+Float.toString(speed));
                if((m)!=0)
                stopping();
                else
                    Toast.makeText(getApplicationContext(), "you must atleast run and then stop ",
                            Toast.LENGTH_SHORT).show();
            }
        });

    }

    private void stopping() {
        Intent i = new Intent(this, two.class);
        i.putExtra("donate", Double.toString(m));
        mchrono.stop();
        startActivity(i);

    }

    @Override
    protected void onStop() {
        super.onStop();


    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {

        switch (requestCode) {
            case 10:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    configurebutton();
                }
                break;
        }
    }


    void configurebutton(){
        // first check for permissions
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION,Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.INTERNET}
                        ,10);
            }
            return;
        }
        // this code won't execute IF permissions are not allowed, because in the line above there is return statement.
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //noinspection MissingPermission
                locationManager.requestLocationUpdates(locationManager.NETWORK_PROVIDER, 0, 0, locationListener);
            }
        });
    }


}

