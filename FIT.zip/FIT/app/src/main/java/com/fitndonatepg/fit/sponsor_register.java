package com.fitndonatepg.fit;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class sponsor_register extends AppCompatActivity {
    Button b;
    dbhelper d;
    EditText t1, t2, t3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sponsor_register);
        d = new dbhelper(this);
        t1 = (EditText) findViewById(R.id.t1);
        t2 = (EditText) findViewById(R.id.t2);
        t3 = (EditText) findViewById(R.id.t3);
        b = (Button) findViewById(R.id.bbbb);
        add();
    }
    public  void add()
    {
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                boolean isInserted = d.insertData(t1.getText().toString(),
                        t2.getText().toString(),
                        t3.getText().toString());
                if (isInserted == true)
                    Toast.makeText(sponsor_register.this, "Data Inserted", Toast.LENGTH_LONG).show();
                else
                    Toast.makeText(sponsor_register.this, "Data not Inserted", Toast.LENGTH_LONG).show();
            }
        });
    }
}


